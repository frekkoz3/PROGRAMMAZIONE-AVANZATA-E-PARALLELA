"""
    Francesco Bredariol SM3201379
    Programmazione Avanzata e Parallela - Progetto Python
    Anno 2024-2025
"""
class BadOperandException(Exception):
    pass

class IllegalOperationException(Exception):
    pass

class IllegalInstructionException(Exception):
    pass